document.addEventListener('prechange', function(event) {
    document.querySelector('ons-toolbar .center')
      .innerHTML = event.tabItem.getAttribute('label');
});






  document.addEventListener('postchange', function (event) {
    console.log('postchange event', event);
  });
  function changeTab() {
    document.getElementById('tabbar').setActiveTab(1);
  }
  function changeButton() {
    document.getElementById('segment').setActiveButton(1);
  }
  function logIndexes() {
    console.log('active button index', document.getElementById('segment').getActiveButtonIndex());
    console.log('active tab index', document.getElementById('tabbar').getActiveTabIndex());
  }





  var showADialog = function(id) {
  var dialog = document.getElementById('my-'+id);

  if (dialog) {
    dialog.show();
  } else {
    ons.createElement(id + '.html', { append: true })
      .then(function(dialog) {
        dialog.show();
      });
  }
};

var hideDialog = function(id) {
  document
    .getElementById(id)
    .hide();
};